document.addEventListener('DOMContentLoaded', () => {
            const navLinks = document.querySelectorAll('header nav ul li a');

            function updateActiveNavLink() {
                const scrollY = window.scrollY;
                navLinks.forEach(link => {
                    const targetId = link.getAttribute('href').slice(1);
                    const targetSection = document.getElementById(targetId);
                    if (targetSection) {
                        const sectionTop = targetSection.offsetTop;
                        const sectionHeight = targetSection.clientHeight;
                        if (scrollY >= sectionTop - 100 && scrollY < sectionTop + sectionHeight - 100) {
                            link.classList.add('active-link');
                        } else {
                            link.classList.remove('active-link');
                        }
                    }
                });
            }

            window.addEventListener('scroll', updateActiveNavLink);
        });

        
        var swiper = new Swiper(".mySwiper", {
            slidesPerView: 1,
            spaceBetween: 30,
            loop: true,
            pagination: {
                el: ".swiper-pagination",
                clickable: true,
            },
            navigation: {
                nextEl: ".swiper-button-next",
                prevEl: ".swiper-button-prev",
            },
            autoplay: {
                delay: 5000,
                disableOnInteraction: false,
            },
        });